# Calculator

Project to create a calculator with Angular

